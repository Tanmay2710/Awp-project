<?php include 'includes/connection.php'; ?>

<?php
session_start();
if (isset($_POST['update'])) {
  $username  = $_POST['username'];
  $password = $_POST['currentpassword'];
  $npassword = $_POST['newpassword'];
  $cpassword = $_POST['confirmpassword']
  mysqli_real_escape_string($conn, $username);
  mysqli_real_escape_string($conn, $password);
$query = "SELECT * FROM users WHERE username = '$username'";
$result = mysqli_query($conn , $query) or die (mysqli_error($conn));

  while ($row = mysqli_fetch_array($result)) {
    $id = $row['id'];
    $user = $row['username'];
    $pass = $row['password'];
    $name = $row['name'];
    $email = $row['email'];
    $role= $row['role'];
    $course = $row['course'];
    if (password_verify($password, $pass )) {
      echo "Current password matches" ;
    }
    else {
      echo "<script>alert('invalid current password')</script>";
    //   window.location.href= 'index.php';";

    }
  }
?>