<?php
include ('includes/connection.php');
include ('includes/adminheader.php');

?>

<script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.4.8/angular.min.js"></script>
<div id="wrapper">

        
       <?php include 'includes/adminnav.php';?>
        <div id="page-wrapper">

            <div class="container-fluid">

                
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Queries 
                            <small><?php echo $_SESSION['name']; ?></small>
                        </h1>
<?php

// if (array_key_exists('reply',$_POST))
// {
//     echo "Reply Button"
// }
// ?>
<div ng-app="query_display" ng-controller="controller" ng-init="display_query_data()">
    <table class="table table-bordered">
        <tr>
            <th>User Name</th>
            <th>Name</th>
            <th>Email</th>
            <th>Query</th>
            <th>Reply</th>
        </tr>
        <tr ng-repeat="x in names">
            <td>{{x.username}}</td>
            <td>{{x.n_name}}</td>
            <td>{{x.email}}</td>
            <td>{{x.q_query}}</td>
            <td><form method="post" action="query_reply.php"><input type="submit" name="q_reply" class="btn btn-success" value="Reply" ></form></td>
        </tr>
</table>
</div>
<script>
    // function query_reply(){
    //     var name = window.prompt("Enter reply: ")
    //     alert("reply sent");
    // }
     var app = angular.module("query_display",[]);
    app.controller("controller", function($scope,$http){
        $scope.display_query_data = function(){
            $http.get("displayquery.php")
            .success(function(data){
                $scope.names=data;
            });
        }
    });
</script>
</body>

</html>
<script src="js/jquery.js"></script>

    
<script src="js/bootstrap.min.js"></script>

