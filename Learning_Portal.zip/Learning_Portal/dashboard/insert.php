<?php  
 //insert.php   
 $conn = mysqli_connect("127.0.0.1:3307","root","","notes" ) or die ("error" . mysqli_error($conn));
 $info = json_decode(file_get_contents("php://input"));  

      $username = mysqli_real_escape_string($conn, $info->username);       
      $n_name = mysqli_real_escape_string($conn, $info->n_name);
      $email = mysqli_real_escape_string($conn, $info->email); 
      $q_query = mysqli_real_escape_string($conn, $info->q_query); 
      $query = "INSERT INTO queries(username,n_name,email,q_query) VALUES ('$username', '$n_name','$email','$q_query')";  
      if(mysqli_query($conn, $query))  
      {  
           echo "Query raised Successfully";  
      }  
      else  
      {  
           echo 'Error';  
      }  
 
 ?> 