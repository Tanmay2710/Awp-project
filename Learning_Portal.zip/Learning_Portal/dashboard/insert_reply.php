<?php  
 //insert.php   
 $conn = mysqli_connect("127.0.0.1:3307","root","","notes" ) or die ("error" . mysqli_error($conn));
 $info = json_decode(file_get_contents("php://input"));  
        $username => $_POST["username"]
      $q_reply = mysqli_real_escape_string($conn, $info->q_reply); 
      $query = "UPDATE `queries` SET `q_reply` = '[$q_reply]' WHERE `username` = '[$username]'";  
      if(mysqli_query($conn, $query))  
      {  
           echo "Reply Successfully";  
      }  
      else  
      {  
           echo 'Error';  
      }  
 
 ?> 