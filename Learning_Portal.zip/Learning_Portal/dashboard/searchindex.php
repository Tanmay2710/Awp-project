<?php include ('includes/connection.php'); ?>
<?php include ('includes/adminheader.php');?>


<!DOCTYPE html>
<html>
 <head>
  <script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.5.7/angular.min.js"></script>
  <style>
  
  </style>
 </head>
 <body>
 
<div id="wrapper">
      <?php include 'includes/adminnav.php';?>

       
        <div id="page-wrapper">
           <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Search XXXX
                        </h1>
                          <div class="container" ng-app="live_search_app" ng-controller="live_search_controller" ng-init="fetchData()">
                            <br />
                            <div class="form-group">
                              <div class="input-group">
                              <span class="input-group-addon">Search</span>
                              <input type="text" name="search_query" ng-model="search_query" ng-keyup="fetchData()" placeholder="Search" class="form-control" />
                              </div>
                            </div>
                            <br />
                            <table class="table table-striped table-bordered">
                              <thead>
                              <tr>
                                <th>Name</th>
                                <th>Description</th>
                                <th>Type</th>
                                <th>Uploaded By</th>
                                <th>Download</th>
                              </tr>
                              </thead>
                              <tbody>
                              <tr ng-repeat="data in searchData">
                                <td>{{ data.file_name }}</td>
                                <td>{{ data.file_description}}</td>
                                <td>{{ data.file_type }}</td>
                                <td>{{ data.file_uploader}}</td>
                                <td>
                                    <?php
                                      $query = "SELECT * FROM uploads WHERE status = 'approved' ORDER BY file_uploaded_on DESC";
                                          $run_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
                                          $row = mysqli_fetch_array($run_query);
                                              // $file_id = $row['file_id'];
                                              // $file_name = $row['file_name'];
                                              // $file_description = $row['file_description'];
                                              // $file_type = $row['file_type'];
                                              // // $file_date = $row['file_uploaded_on'];
                                              $file = $row['file'];
                                              //$file_uploader = $row['file_uploader'];
                                              echo "<a href='allfiles/$file' target='_blank' style='color:green'>Download </a>";
                                          
                                      

                                    ?>
                                  </td>
                              </tr>
                              </tbody>
                            </table>
                          </div>
                    </div>
                </div>
          </div>
    </div>
  </div>
  

                

  <script src="js/jquery.js"></script>

    
<script src="js/bootstrap.min.js"></script>

 </body>
</html>

<script>
var app = angular.module('live_search_app', []);
app.controller('live_search_controller', function($scope, $http){
 $scope.fetchData = function(){
  $http({
   method:"POST",
   url:"fetch.php",
   data:{search_query:$scope.search_query}
  }).success(function(data){
   $scope.searchData = data;
  });
 };
});
</script>
