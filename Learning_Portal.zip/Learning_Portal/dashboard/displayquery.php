<?php
$conn = mysqli_connect("127.0.0.1:3307","root","","notes" ) or die ("error" . mysqli_error($conn));
$output=array();
$query="SELECT * FROM queries";
$result=mysqli_query($conn,$query);
if(mysqli_num_rows($result)>0){
    while($row=mysqli_fetch_array($result)){
        $output[]=$row;
    }
    echo json_encode($output);
}
?>