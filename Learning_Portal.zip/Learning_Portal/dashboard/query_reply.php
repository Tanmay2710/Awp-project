<?php include ('includes/connection.php'); ?>
<?php include('includes/adminheader.php');  ?>
 
     <div ng-app="insert_reply" ng-controller="controller">
         Reply:
         <input id="q_reply" name="q_reply" placeholder="Enter reply" required="" tabindex="1" type="text" > 
         <input id="q_replybtn" type="submit" value="Send reply" ng-click="insert_reply()" >
</div>
 </body>
 <script>
    var app=angular.module("insert_reply",[]);
    app.controller("controller",function($scope,$http){
        $scope.insert_reply=function(){
            $http.post(
                "insert_reply.php",
                {'q_reply':$scope.q_reply}
                ).success(function(data){
                    alert(data);
                    $scope.q_reply="";
            });
        }
    });
</script>
 