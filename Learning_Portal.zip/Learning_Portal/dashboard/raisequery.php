<?php
include ('includes/connection.php');
include ('includes/adminheader.php');
?>


<html>  
      <head>     
           <script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.4.8/angular.min.js"></script>  
      </head>  
<div id="wrapper">

        
       <?php include 'includes/adminnav.php';?>
        <div id="page-wrapper">

            <div class="container-fluid">

                
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Raise Query
                            <small><?php echo $_SESSION['name']; ?></small>
                        </h1>

                        <div class="container">
                            <div ng-app="insert_query" ng-controller="controller">
                                <label>User Name</label>
                                <input type="text" name="username" ng-model="username" class="form-control" placeholder='Enter Username'></br>
                                <label>Name</label>
                                <input type="text" name="n_name" ng-model="n_name" class="form-control" placeholder='Enter Name'></br>
                                <label>Email</label>
                                <input type="email" name="email" ng-model="email" class="form-control" placeholder='Enter Email Id'></br>
                                <label>Query</label>
                                <input type="text" name="q_query" ng-model="q_query" class="form-control" placeholder='Enter Query here'></br>
                                <input type="submit" name="insert" class="btn btn-success" ng-click="insert()" value="Raise" ></br>
                            </div>
                        </div>
    <script>
        
    var app=angular.module("insert_query",[]);
    app.controller("controller",function($scope,$http){
        $scope.insert=function(){
            $http.post(
                "insert.php",
                {'username':$scope.username, 'n_name':$scope.n_name, 'email':$scope.email, 'q_query':$scope.q_query}
                ).success(function(data){
                    alert(data);
                    $scope.username="";
                    $scope.n_name="";
                    $scope.email="";
                    $scope.q_query="";
            });
        }
    });
</script>
</body>
</html>

<script src="js/jquery.js"></script>

    
<script src="js/bootstrap.min.js"></script>

