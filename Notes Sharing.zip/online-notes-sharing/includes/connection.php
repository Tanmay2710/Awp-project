<?php

$conn = mysqli_connect("127.0.0.1:3306 ","root","","notes" ) or die ("error" . mysqli_error($conn));
?>
