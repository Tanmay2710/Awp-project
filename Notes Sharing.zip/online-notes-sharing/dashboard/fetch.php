<?php

//fetch.php


$connect = new PDO("mysql:host=127.0.0.1:3306;dbname=notes", "root", "");

$form_data = json_decode(file_get_contents("php://input"));

$query = '';
$data = array();

if(isset($form_data->search_query))
{
 $search_query = $form_data->search_query;
 $query = "
 SELECT * FROM uploads
 WHERE (file_name LIKE '%$search_query%' 
 OR file_description LIKE '%$search_query%' 
 OR file_type LIKE '%$search_query%' 
 OR file_uploader LIKE '%$search_query%')
 ";
}
else
{
 $query = "SELECT * FROM uploads ORDER BY file_name ASC";
}

$statement = $connect->prepare($query);

if($statement->execute())
{
 while($row = $statement->fetch(PDO::FETCH_ASSOC))
 {
  $data[] = $row;
 }
 echo json_encode($data);
}

?>