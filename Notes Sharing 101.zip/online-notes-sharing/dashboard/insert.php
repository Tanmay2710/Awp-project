<?php  
 //insert.php   
 $conn = mysqli_connect("127.0.0.1:3306","root","","notes" ) or die ("error" . mysqli_error($conn));
 $info = json_decode(file_get_contents("php://input"));  
 if(count($data) > 0)  
 {  
      $username = mysqli_real_escape_string($connect, $info->username);       
      $n_name = mysqli_real_escape_string($connect, $info->n_name);
      $email = mysqli_real_escape_string($connect, $info->email); 
      $q_query = mysqli_real_escape_string($connect, $info->q_query); 
      $query = "INSERT INTO queries(username,n_name,email,q_query) VALUES ('$username', '$n_name','$email','$q_query')";  
      if(mysqli_query($conn, $query))  
      {  
           echo "Query raised Successfully";  
      }  
      else  
      {  
           echo 'Error';  
      }  
 }  
 ?> 